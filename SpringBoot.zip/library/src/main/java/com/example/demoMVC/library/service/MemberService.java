package com.example.demoMVC.library.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoMVC.library.entity.Member;
import com.example.demoMVC.library.repository.MemberRepository;

@Service
public class MemberService {
	
	@Autowired
	MemberRepository MemberRepository;

	public Member addmember(Member member) {
		return MemberRepository.save(member);
	}

	public Optional<Member> getMemberById(int id) {
		return MemberRepository.findById(id);
	}

	public List<Member> getAllMember() {
		return MemberRepository.findAll();
	}


	public Member updateMember(int id, Member updateMember) {
		return MemberRepository.findById(id).map(member ->
		{
			member.setName(updateMember.getName());
			member.setAuthor(updateMember.getAuthor());
			return MemberRepository.save(member);
		}).orElse(null);
	}

	public void deleteById(int id) {
		MemberRepository.deleteById(id);
	}

}
