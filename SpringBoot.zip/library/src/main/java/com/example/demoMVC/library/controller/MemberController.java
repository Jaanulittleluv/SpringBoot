package com.example.demoMVC.library.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoMVC.library.entity.Member;
import com.example.demoMVC.library.service.MemberService;

@RestController
@RequestMapping("/member")
public class MemberController {
	@Autowired
	MemberService MemberService;
	
	@PostMapping("/add")
	public Member addmember(@RequestBody Member member) {
		return MemberService.addmember(member);
	}
	
	@GetMapping("/{id}")
	public Optional<Member> getMemberById(@PathVariable int id){
		return MemberService.getMemberById(id);
	}

	@GetMapping("/all")
	public List<Member> getAllMember(){
		return MemberService.getAllMember();
	}
	
	@PutMapping("/update/{id}")
	public Member updateMember(@PathVariable int id, @RequestBody Member updateMember) {
		return MemberService.updateMember(id,updateMember);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable int id) {
		MemberService.deleteById(id);
	}
}
