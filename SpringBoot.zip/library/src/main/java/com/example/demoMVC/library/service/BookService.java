package com.example.demoMVC.library.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoMVC.library.entity.Book;
import com.example.demoMVC.library.repository.BookRepository;

@Service
public class BookService {

	@Autowired
	BookRepository BookRepository;

	public Book addbook(Book book) {
		return BookRepository.save(book);
	}
}
